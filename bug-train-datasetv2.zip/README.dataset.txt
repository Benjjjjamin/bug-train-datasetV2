# Oriental-fruit-fly > bug-train-datasetV2
https://universe.roboflow.com/rajamangala-university-of-technology-lanna-nqqeb/oriental-fruit-fly

Provided by a Roboflow user
License: CC BY 4.0

